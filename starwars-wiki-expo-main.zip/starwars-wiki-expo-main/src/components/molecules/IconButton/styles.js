import styled from 'styled-components/native'

export const ButtonContainer = styled.TouchableOpacity`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`
