export const colors = {
  white: '#FFFFFF',
  light: '#E5E5E5',
  red: '#E60C0D',
  dark: '#161616',
  black: '#000000',
  grey: '#5B5B5B',
  darkTransparent: 'rgba(22, 22, 22, 0.7)',
}
