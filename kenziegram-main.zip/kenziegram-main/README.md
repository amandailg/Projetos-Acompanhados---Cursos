# Kenziegram

Repositório criado para o projeto desenvolvido durante o evento Projeto Dev.

## Download

Para baixar os códigos na sua máquina, clique no botão verde escrito "Code", e em seguida selecione a opção "Download ZIP". Depois, você só precisa extrair o projeto em sua máquina e abrí-lo no VS Code, ou qualquer outro editor de sua preferência.

## Layout

- [Kenziegram](./assets/img/kenziegram.png)

Evento realizado nos dias 02 a 05 de Agosto de 2021.